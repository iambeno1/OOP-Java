public class StaticMethod {
    // Static method untuk menghitung jumlah
    public static int sum(int a, int b) {
        return a + b;
    }

    // Static method untuk menghitung perkalian
    public static int multiply(int a, int b) {
        return a * b;
    }
}
