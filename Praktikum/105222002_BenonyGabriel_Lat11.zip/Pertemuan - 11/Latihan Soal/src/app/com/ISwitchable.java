package app.com;

public interface ISwitchable {
    void turnOn();
    void turnOff();
}
