package com.hero;

public class HeroAgility extends Hero {
    public HeroAgility(String name){
        super(name);
    }

    public void levelUp(){
        this.setLevel(1);
    }

}
