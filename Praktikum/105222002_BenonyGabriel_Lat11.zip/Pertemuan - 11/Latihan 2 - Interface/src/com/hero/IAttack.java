package com.hero;

public interface IAttack {
    public void attack(Hero enemy);
    
}