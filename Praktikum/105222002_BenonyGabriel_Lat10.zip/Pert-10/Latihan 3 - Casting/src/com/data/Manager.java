package com.data;

public class Manager extends Employee {
    Manager(String name) {
        super(name);
    }
}
