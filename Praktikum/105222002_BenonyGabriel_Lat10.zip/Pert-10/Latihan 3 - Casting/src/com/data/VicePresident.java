package com.data;

public class VicePresident extends Employee {
    VicePresident(String name) {
        super(name);
    }
}
