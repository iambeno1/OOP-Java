public class Main {
    public static void main(String[] args) {
        HitungObjek obj1 = new HitungObjek(); // buat objek pertama
        HitungObjek obj2 = new HitungObjek(); // buat objek kedua
        HitungObjek obj3 = new HitungObjek(); // buat objek ketiga

        System.out.println("Jumlah objek yang telah dibuat: " + HitungObjek.getCount());
    }
}
