package kampus;

/**
 * Interface AktivitasKampus mendefinisikan metode yang harus diimplementasikan oleh setiap class yang terlibat dalam aktivitas kampus.
 */
public interface AktivitasKampus {
    void menghadiriKuliah();
    void mengikutiOrganisasi();
}
