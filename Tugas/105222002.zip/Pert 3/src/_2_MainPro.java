public class _2_MainPro {
    // Deklarasi global variabel
    int[] angka;
    String[] pesan;

    public _2_MainPro(int indeksnya){
        
    }
    public static void main(String[] args) {
        _2_MainPro objek = new _2_MainPro(5);
        _2_MainPro[] objekKedua
    }
}
