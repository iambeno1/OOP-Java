 // var counter = 1;
        // for(; counter <= 10;){
        //     System.out.println("Perulangan ke-" + counter);
        //     counter++;
        // }