public class Ternary {
    public static void main(String[] args) {
        var nilai = 75;
        String ucapan = nilai >= 17 ? "Selamat kamu lulus" : "Coba lagi";
        System.out.println(ucapan);
    }
}
