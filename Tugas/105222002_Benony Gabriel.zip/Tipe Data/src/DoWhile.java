public class DoWhile {
    public static void main(String[] args) {
        var counter = 1;
                do {
                    System.out.println("Perulangan ke-" + counter);
                    counter++;
                } while (counter <= 10);
    }
}
