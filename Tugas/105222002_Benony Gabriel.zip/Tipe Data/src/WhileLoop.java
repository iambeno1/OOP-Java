public class WhileLoop {
    public static void main(String[] args) {
        var counter = 1;
        while (counter <= 10) {
            System.out.println("Perulangan ke-" + counter);
            counter++;
        }
    }
}
