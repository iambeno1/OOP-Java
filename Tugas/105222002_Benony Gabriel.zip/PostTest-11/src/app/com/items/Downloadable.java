package app.com.items;

// Membuat interface Downloadable
public interface Downloadable {

    void download();
} 