package app.com.items;

// Membuat interface Loanable
public interface Loanable {
    
    void loan();
    void returnItem();
    
}
