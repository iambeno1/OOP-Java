public class Parent {
    protected String name;

    // Konstruktor Parent
    public Parent(String name) {
        this.name = name;
    }

    // Method untuk menampilkan informasi
    public void displayInfo() {
        System.out.println("Parent - Nama : " + name);
    }
}
